import logo from '../images/TestLogo.svg';
import Home from '../images/Home.svg';
import Patients from '../images/Patients.svg';
import Schedule from '../images/Schedule.svg';
import Message from '../images/Message.svg';
import Transactions from '../images/Transactions.svg';
import Doctor from '../images/Doctor.png';
import Gear from '../images/Gear.svg';
import EllipsisVertical from '../images/Ellipsis_Vertical.svg';
import './Header.css'

const Header = () => {
    return(
        <div className="header-container">
            <div className="logo">
                <img src ={logo} alt ="Test logo" />
            </div>
            <div className="header-menu">
                <div className="header-menu-item">
                    <img src ={Home} alt ="Home logo" width="16" height="17" />
                    <span>Overview</span>
                </div>
                <div className="header-menu-item header-menu-item-patients">
                    <img src ={Patients} alt ="Patients logo" width="16" height="17" />
                    <span>Patients</span>
                </div>
                <div className="header-menu-item">
                    <img src ={Schedule} alt ="Schedule logo" width="25" height="25" />
                    <span>Schedule</span>
                </div>
                <div className="header-menu-item">
                    <img src ={Message} alt ="Message logo" width="16" height="17" />
                    <span>Message</span>
                </div>
                <div className="header-menu-item">
                    <img src ={Transactions} alt ="Transactions logo" width="16" height="17" />
                    <span>Transactions</span>
                </div>
            </div>
            <div className="header-menu profile-menu">
                <div className="profile-menu-item"><img src ={Doctor} alt ="Doctor logo"/></div>
                <div className="profile-menu-item">
                    <div className="bold">Dr. Jose Simmons</div>
                    <div className="font12 light-gray">General Practioner</div>
                </div>
                <div className="profile-menu-item border-right"></div>
                <div className="profile-menu-item"><img src ={Gear} alt ="Gear logo"/></div>
                <div className="profile-menu-item"><img src ={EllipsisVertical} alt ="Ellipsis logo"/></div>
            </div>
        </div>
    )
}
export default Header