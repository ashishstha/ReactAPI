import React, { useContext } from 'react';
import UserContext from "../../UserContext";
import Ellipsis from '../images/Ellipsis.svg';
import Search from '../images/Search.svg';
import './PatientsList.css'

const PatientsList = () => {
    const users = useContext(UserContext)
    return(
        <div className="patients-list-container">
            <div className="patients-heading">
                <h2>Patients</h2>
                <img src ={Search} alt ="Search logo" width="16" height="17" />

            </div>
            <ul>
                {(users || []).map((user)=>{
                    return(
                        <li>
                        <div className="patient-container">
                            <div className="patient-content patient-image">
                               <img src={user?.profile_picture} alt={user?.name} width="44" height="44"/>
                            </div>
                            <div className="patient-content patient-details">
                                <div className="bold">{user?.name}</div>
                                <div>{user?.gender}, {user?.age}</div>
                            </div>
                            <div className="patient-content patient-content-ellipsis patient-ellipsis">
                            <img src={Ellipsis} alt="ellipsis" />

                                </div>

                        </div>
                        </li>

                    )
                })}
            </ul>
        </div>
    )
}

export default PatientsList