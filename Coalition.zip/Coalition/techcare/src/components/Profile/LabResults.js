import DownloadIcon from '../images/DownloadIcon.svg';

const LabResults = (user) => {
        return(
            <div className="profile-container mtb20">
                <h2>Lab Results</h2>
                <div className="lab-result-details font13">
                    <ul>
                    {(user?.user?.lab_results || []).map((item) => {
                        return(
                           <li>
                                <div>{item}</div>
                                <div><img src={DownloadIcon}  alt = "download icon" /></div>
                            </li>
                        )
                    })}
                    </ul>
                </div>
            </div>
        )

}   
export default LabResults;