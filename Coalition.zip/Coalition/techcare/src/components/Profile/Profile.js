import React, { useContext } from 'react';
import LabResults from './LabResults';
import UserContext from "../../UserContext";
import ProfilePic from '../images/ProfilePic.png';
import BirthIcon from '../images/BirthIcon.svg';
import GenderIcon from '../images/GenderIcon.svg';
import PhoneIcon from '../images/PhoneIcon.png';
import InsuranceIcon from '../images/InsuranceIcon.png';
import './Profile.css';

const Profile = () => {
    const users = useContext(UserContext);
    const singleUser = (users || []).find((item) => item?.name === "Jessica Taylor");
    return(
        <div className="profile-container-outer">
        <div className="profile-container">
            <div className="profile-picture">
                <img src={ProfilePic}  alt = {singleUser?.name} width="200" height="200" />
            </div>
            <div className="profile-picture">
                <h2>{singleUser?.name}</h2>
            </div>
            <div className="profile-details">
                <ul>
                    <li>
                        <div className="listIcon">
                            <img src={BirthIcon}  alt = "birth icon" />
                        </div>
                        <div className="profile-details-content">
                            <div>Date Of Birth</div>
                            <div className="bold">{singleUser?.date_of_birth}</div>
                        </div>
                    </li>
                    <li>
                        <div className="listIcon">
                            <img src={GenderIcon}  alt = "gender icon" />
                        </div>
                        <div className="profile-details-content">
                            <div>Gender</div>
                            <div className="bold">{singleUser?.gender}</div>
                        </div>
                    </li>
                    <li>
                        <div className="listIcon">
                            <img src={PhoneIcon}  alt = "phone icon" />
                        </div>
                        <div className="profile-details-content">
                            <div>Contact Info.</div>
                            <div className="bold">{singleUser?.phone_number}</div>
                        </div>
                    </li>
                    <li>
                        <div className="listIcon">
                            <img src={PhoneIcon}  alt = "phone icon" />
                        </div>
                        <div className="profile-details-content">
                            <div>Emergency Contact</div>
                            <div className="bold">{singleUser?.emergency_contact}</div>
                        </div>
                    </li>
                    <li>
                        <div className="listIcon">
                            <img src={InsuranceIcon}  alt = "insurance icon" />
                        </div>
                        <div className="profile-details-content">
                            <div>Insurance Provider</div>
                            <div className="bold">{singleUser?.insurance_type}</div>
                        </div>
                    </li>
                </ul>
                <div className="profile-button">
                    <div className='green-rounded-background bold'>
                        Show All Information
                    </div>
                </div>
            </div>
        </div>
        <LabResults  user={singleUser} />
        </div>
    )
}

export default Profile