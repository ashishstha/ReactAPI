import DiagnosisHistory from './DiagnosisHistory';
import DiagnosisList from './DiagnosisList';
import './Diagnosis.css';

import './Diagnosis.css'

const Diagnosis = () => {
    return(
        <div className="diagnosis-container">
            <DiagnosisHistory />
            <DiagnosisList />

        </div>
    )
}

export default Diagnosis