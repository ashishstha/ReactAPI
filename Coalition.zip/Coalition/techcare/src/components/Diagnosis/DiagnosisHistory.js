import "chart.js/auto";
import React, { useContext } from 'react';
import UserContext from "../../UserContext";
import { Line } from "react-chartjs-2";
import ArrowDown from '../images/ArrowDown.svg';
import ArrowUp from '../images/ArrowUp.svg';
import Respiratory from '../images/Respiratory.svg';
import Temperature from '../images/Temperature.svg';
import Heart from '../images/Heart.svg';
import './DiagnosisHistory.css';

const DiagnosisHistory = () => {
    const users = useContext(UserContext)
    const singleUser = (users || []).find((item) => item?.name === "Jessica Taylor");
    const labelForChart = (singleUser?.diagnosis_history || []).map(item=> `${item.month.substring(0,3)}, ${item.year}`).slice(0,6);
    const systolicData = (singleUser?.diagnosis_history || []).map(item=> item.blood_pressure.systolic.value).slice(0,6);
    const diastolicData = (singleUser?.diagnosis_history || []).map(item=> item.blood_pressure.diastolic.value).slice(0,6);


    const data = {
        labels: labelForChart,
        options: {
            plugins: {
            legend: {
                display: true,
              align: "start",
              position: "right"
            },
          },
        },
        datasets: [
        {
            label: "Systolic",
            data: systolicData,
            fill: false,
            borderColor: "#E66FD2",
            
        },
        {
            label: "Diastolic",
            data: diastolicData,
            fill: false,
            borderColor: "#8C6FE6"
          },
        ]
    };
    const options = {
        plugins: {
            legend: {
                display: false
             },
             tooltips: {
                enabled: false
             }
         
        }
      };
    return(
        <div className="diagnosisList-container">
            <h2>Diagnostis History</h2>
            <div className="diagnosis-history-chart">
                <div className="diagnosis-history-chart-heading">
                    <div className="font18">Blood Pressure</div>
                    <div className="diagnosis-history-chart-month">
                        <select name="category" className="font14">
                            <option id="0" >Last 6 months</option>
                            <option id="1" >Last 3 months</option>
                        </select>
                    </div>
                </div>
                <div className="diagnosis-history-chart-content mt20">
                    <Line data={data}  options={options} />
                    <div className="diagnosis-history-chart-content-systolic">
                        <div className="diagnosis-history-chart-content-text">
                            <div className="dot systolic"></div>
                            <div className="bold">Systolic</div>
                        </div>
                        <div className="font22 mt10">160</div>
                        <div className="diagnosis-history-chart-content-text mt10">
                            <div>
                                <img src ={ArrowUp} alt ="Arrow up logo"  /> 
                            </div>
                            <div className="ml10 font14">Higher than Average</div>
                        </div>
                        <hr className="mt20"/>
                        <div className="mt20">
                            <div className="diagnosis-history-chart-content-text">
                                <div className="dot diastolic"></div>
                                <div className="bold">Diastolic</div>
                            </div>
                            <div className="font22 mt10">78</div>
                            <div className="diagnosis-history-chart-content-text mt10">
                                <div>
                                    <img src ={ArrowDown} alt ="Arrow down logo"  /> 
                                </div>
                                <div className="ml10 font14">Lower than Average</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="diagnosis-history-temperature-container mt20">
                <div className="diagnosis-history-temperature-common diagnosis-history-respiratory">
                    <img src ={Respiratory} alt ="Respiratory logo"  /> 
                    <div className="mt10 font16">Respiratory Rate</div>
                    <div className="font30 mt10">20 bpm</div>
                    <div className="mt10 font14">Normal</div>
                </div>
                <div className="diagnosis-history-temperature-common diagnosis-history-temperature">
                    <img src ={Temperature} alt ="Temperature logo"  /> 
                    <div className="mt10 font16">Temperature</div>
                    <div className="font30 mt10">98.6°F</div>
                    <div className="mt10 font14">Normal</div>
                </div>
                <div className="diagnosis-history-temperature-common diagnosis-history-heart-rate">
                    <img src ={Heart} alt ="Heart rate logo"  /> 
                    <div className="mt10 font16">Temperature</div>
                    <div className="font30 mt10">78 bpm</div>
                    <div className="mt10 flex">
                        <div>
                            <img src ={ArrowDown} alt ="Arrow down logo"  /> 
                        </div>
                        <div className="ml10 font14">
                             Lower than average
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default DiagnosisHistory