import React, { useContext } from 'react';
import UserContext from "../../UserContext";
import './DiagnosisList.css';

const DiagnosisList = () => {
    const users = useContext(UserContext)
    const singleUser = (users || []).find((item) => item?.name === "Jessica Taylor");
    return(
        <div className="diagnosisList-container">
            <h2>Diagnostis List</h2>
            <div className="diagnosisList-heading">
                <div>Problem/Diagnosis</div>
                <div>Description</div>
                <div>Status</div>
            </div>
            <div className="diagnosisList-content">
                <ul>
                    {(singleUser?.diagnostic_list || []).map((item) => {
                        return(
                           <li>
                            <div>{item.name}</div>
                            <div>{item.description}</div>
                            <div>{item.status}</div>

                            </li>
                        )
                    })}
                </ul>

            </div>
        </div>
    )
}
export default DiagnosisList