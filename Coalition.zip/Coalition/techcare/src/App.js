import React, {useState, useEffect } from 'react';
import Header from './components/Header/Header';
import PatientsList from './components/PatientsList/PatientsList';
import Diagnosis from './components/Diagnosis/Diagnosis';
import Profile from './components/Profile/Profile';
import UserContext from "./UserContext";
import './App.css';

function App() {
  const [users, setUsers] = useState(null)
  const [loading, setLoading] = useState(true)

useEffect(() => {
  const username = 'coalition';
  const password = 'skills-test';
  let auth = btoa(`${username}:${password}`);
  fetch('https://fedskillstest.coalitiontechnologies.workers.dev', {
    headers: {
      'Authorization': `Basic ${auth}`
    }
  }).then(async function (response) {
    if (response.ok) {
      const data =  await response.json();
      const uniqueUsers = Array.from(new Set(data.map(a => a.profile_picture)))
 .map(id => {
   return data.find(a => a.profile_picture === id)
 })
      setUsers(uniqueUsers);
      setLoading(false);
    }
    throw response;
  }).then(function (data) {
    console.log(data);
  }).catch(function (error) {
    console.warn(error);
  });
},[])

  if(loading) {
    return (<div> Loading....</div>)
  }
  return (
    <UserContext.Provider value={users}>
      <div className="App">
        <Header />
        <div className="container">
              <PatientsList />
              <Diagnosis />
              <Profile />
        </div>
      </div>
    </UserContext.Provider>
  );
}

export default App;
