Author: Ashish Shrestha
Date: 03/24/2025
Application: This is a React based application developed by creating smaller components to make it modular and resuable. API call is made as a test data.