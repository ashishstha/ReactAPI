Author: Ashish Shrestha
Date: 03/24/2025
Application: This is a React based application developed by creating smaller components to make it modular and resuable. API call is made as a test data.

Instructions:
1. Download the zip file. Unzip it.
2.Go to Coalition -> techcare
3. Do npm install
4. Run npm run start
5. Application will open in browser with http://localhost:3000